﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Bolnička_evidencija
{
    public partial class MainForm : Form
    {
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelTop = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBoxKriz = new System.Windows.Forms.PictureBox();
            this.Zatvori = new System.Windows.Forms.Label();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panelUrediPacijenta = new System.Windows.Forms.Panel();
            this.panelListaCekanja = new System.Windows.Forms.Panel();
            this.panelPregled = new System.Windows.Forms.Panel();
            this.panelOBolnici = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnSpremiPregled = new System.Windows.Forms.Button();
            this.txtOpisPregled = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtDatumPregled = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtPovijestPregled = new System.Windows.Forms.TextBox();
            this.cbDatumPregled = new System.Windows.Forms.ComboBox();
            this.txtPorukaPregled = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btnPosaljiPoruku = new System.Windows.Forms.Button();
            this.dataGridViewCekanje = new System.Windows.Forms.DataGridView();
            this.cbCekanjeUredi = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtIdUredi = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSpremiUredenog = new System.Windows.Forms.Button();
            this.txtMobitelUredi = new System.Windows.Forms.TextBox();
            this.txtGodinaUredi = new System.Windows.Forms.TextBox();
            this.txtEmailUredi = new System.Windows.Forms.TextBox();
            this.txtAdresaUredi = new System.Windows.Forms.TextBox();
            this.txtPrezimeUredi = new System.Windows.Forms.TextBox();
            this.txtImeUredi = new System.Windows.Forms.TextBox();
            this.cbKrvUredi = new System.Windows.Forms.ComboBox();
            this.cbSpolUredi = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnListaPacijenata = new System.Windows.Forms.Button();
            this.lblNavigacija = new System.Windows.Forms.Label();
            this.btnListaČekanja = new System.Windows.Forms.Button();
            this.pictureBoxGif = new System.Windows.Forms.PictureBox();
            this.pictureBoxVuv = new System.Windows.Forms.PictureBox();
            this.panelListaPacijenata = new System.Windows.Forms.Panel();
            this.panelDodajPacijenta = new System.Windows.Forms.Panel();
            this.cbCekanje = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.btnSpremiNovog = new System.Windows.Forms.Button();
            this.txtMobitel = new System.Windows.Forms.TextBox();
            this.lblId = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.txtGodina = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAdresa = new System.Windows.Forms.TextBox();
            this.txtPrezime = new System.Windows.Forms.TextBox();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.cbKrv = new System.Windows.Forms.ComboBox();
            this.cbSpol = new System.Windows.Forms.ComboBox();
            this.lblMobitel = new System.Windows.Forms.Label();
            this.lblKrv = new System.Windows.Forms.Label();
            this.lblSpol = new System.Windows.Forms.Label();
            this.lblGodina = new System.Windows.Forms.Label();
            this.lblAdresa = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblPrezime = new System.Windows.Forms.Label();
            this.lblIme = new System.Windows.Forms.Label();
            this.dataGridViewPacijenti = new System.Windows.Forms.DataGridView();
            this.Dodaj = new System.Windows.Forms.Button();
            this.btnPocetna = new System.Windows.Forms.Button();
            this.btnOBolnici = new System.Windows.Forms.Button();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKriz)).BeginInit();
            this.panelBottom.SuspendLayout();
            this.panelUrediPacijenta.SuspendLayout();
            this.panelListaCekanja.SuspendLayout();
            this.panelPregled.SuspendLayout();
            this.panelOBolnici.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCekanje)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVuv)).BeginInit();
            this.panelListaPacijenata.SuspendLayout();
            this.panelDodajPacijenta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPacijenti)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.PowderBlue;
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Controls.Add(this.pictureBoxKriz);
            this.panelTop.Controls.Add(this.Zatvori);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(930, 81);
            this.panelTop.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(161, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 28);
            this.label2.TabIndex = 3;
            this.label2.Text = "U Virovitici";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(68, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Bolnica Veleučilišta";
            // 
            // pictureBoxKriz
            // 
            this.pictureBoxKriz.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxKriz.Image")));
            this.pictureBoxKriz.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxKriz.Name = "pictureBoxKriz";
            this.pictureBoxKriz.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxKriz.TabIndex = 1;
            this.pictureBoxKriz.TabStop = false;
            // 
            // Zatvori
            // 
            this.Zatvori.AutoSize = true;
            this.Zatvori.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Zatvori.Location = new System.Drawing.Point(891, 12);
            this.Zatvori.Name = "Zatvori";
            this.Zatvori.Size = new System.Drawing.Size(27, 25);
            this.Zatvori.TabIndex = 0;
            this.Zatvori.Text = "X";
            this.Zatvori.Click += new System.EventHandler(this.Zatvori_Click);
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.Color.PowderBlue;
            this.panelBottom.Controls.Add(this.label5);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 489);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(930, 73);
            this.panelBottom.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.PowderBlue;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(162, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(600, 22);
            this.label5.TabIndex = 3;
            this.label5.Text = "Izradio LEO JOVANOVIĆ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelUrediPacijenta
            // 
            this.panelUrediPacijenta.Controls.Add(this.panelListaCekanja);
            this.panelUrediPacijenta.Controls.Add(this.cbCekanjeUredi);
            this.panelUrediPacijenta.Controls.Add(this.label4);
            this.panelUrediPacijenta.Controls.Add(this.txtIdUredi);
            this.panelUrediPacijenta.Controls.Add(this.label6);
            this.panelUrediPacijenta.Controls.Add(this.label7);
            this.panelUrediPacijenta.Controls.Add(this.btnSpremiUredenog);
            this.panelUrediPacijenta.Controls.Add(this.txtMobitelUredi);
            this.panelUrediPacijenta.Controls.Add(this.txtGodinaUredi);
            this.panelUrediPacijenta.Controls.Add(this.txtEmailUredi);
            this.panelUrediPacijenta.Controls.Add(this.txtAdresaUredi);
            this.panelUrediPacijenta.Controls.Add(this.txtPrezimeUredi);
            this.panelUrediPacijenta.Controls.Add(this.txtImeUredi);
            this.panelUrediPacijenta.Controls.Add(this.cbKrvUredi);
            this.panelUrediPacijenta.Controls.Add(this.cbSpolUredi);
            this.panelUrediPacijenta.Controls.Add(this.label8);
            this.panelUrediPacijenta.Controls.Add(this.label9);
            this.panelUrediPacijenta.Controls.Add(this.label10);
            this.panelUrediPacijenta.Controls.Add(this.label11);
            this.panelUrediPacijenta.Controls.Add(this.label12);
            this.panelUrediPacijenta.Controls.Add(this.label13);
            this.panelUrediPacijenta.Controls.Add(this.label14);
            this.panelUrediPacijenta.Controls.Add(this.label15);
            this.panelUrediPacijenta.Location = new System.Drawing.Point(229, 98);
            this.panelUrediPacijenta.Name = "panelUrediPacijenta";
            this.panelUrediPacijenta.Size = new System.Drawing.Size(689, 376);
            this.panelUrediPacijenta.TabIndex = 41;
            // 
            // panelListaCekanja
            // 
            this.panelListaCekanja.Controls.Add(this.panelPregled);
            this.panelListaCekanja.Controls.Add(this.dataGridViewCekanje);
            this.panelListaCekanja.Location = new System.Drawing.Point(0, 0);
            this.panelListaCekanja.Name = "panelListaCekanja";
            this.panelListaCekanja.Size = new System.Drawing.Size(689, 376);
            this.panelListaCekanja.TabIndex = 52;
            // 
            // panelPregled
            // 
            this.panelPregled.Controls.Add(this.btnSpremiPregled);
            this.panelPregled.Controls.Add(this.txtOpisPregled);
            this.panelPregled.Controls.Add(this.label22);
            this.panelPregled.Controls.Add(this.txtDatumPregled);
            this.panelPregled.Controls.Add(this.label21);
            this.panelPregled.Controls.Add(this.txtPovijestPregled);
            this.panelPregled.Controls.Add(this.cbDatumPregled);
            this.panelPregled.Controls.Add(this.txtPorukaPregled);
            this.panelPregled.Controls.Add(this.label19);
            this.panelPregled.Controls.Add(this.label16);
            this.panelPregled.Controls.Add(this.label17);
            this.panelPregled.Controls.Add(this.label18);
            this.panelPregled.Controls.Add(this.btnPosaljiPoruku);
            this.panelPregled.Location = new System.Drawing.Point(0, 0);
            this.panelPregled.Name = "panelPregled";
            this.panelPregled.Size = new System.Drawing.Size(689, 376);
            this.panelPregled.TabIndex = 73;
            // 
            // panelOBolnici
            // 
            this.panelOBolnici.Controls.Add(this.textBox1);
            this.panelOBolnici.Controls.Add(this.label23);
            this.panelOBolnici.Location = new System.Drawing.Point(229, 98);
            this.panelOBolnici.Name = "panelOBolnici";
            this.panelOBolnici.Size = new System.Drawing.Size(689, 376);
            this.panelOBolnici.TabIndex = 83;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(46, 75);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(596, 278);
            this.textBox1.TabIndex = 76;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.PowderBlue;
            this.label23.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Location = new System.Drawing.Point(42, 32);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(600, 26);
            this.label23.TabIndex = 41;
            this.label23.Text = "Povijest VUV bolnice";
            this.label23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnSpremiPregled
            // 
            this.btnSpremiPregled.AutoSize = true;
            this.btnSpremiPregled.BackColor = System.Drawing.Color.PowderBlue;
            this.btnSpremiPregled.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSpremiPregled.ForeColor = System.Drawing.Color.White;
            this.btnSpremiPregled.Location = new System.Drawing.Point(305, 309);
            this.btnSpremiPregled.Name = "btnSpremiPregled";
            this.btnSpremiPregled.Size = new System.Drawing.Size(96, 32);
            this.btnSpremiPregled.TabIndex = 82;
            this.btnSpremiPregled.Text = "Spremi";
            this.btnSpremiPregled.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSpremiPregled.UseVisualStyleBackColor = false;
            this.btnSpremiPregled.Click += new System.EventHandler(this.btnSpremiPregled_Click);
            // 
            // txtOpisPregled
            // 
            this.txtOpisPregled.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtOpisPregled.Location = new System.Drawing.Point(142, 275);
            this.txtOpisPregled.Name = "txtOpisPregled";
            this.txtOpisPregled.Size = new System.Drawing.Size(500, 28);
            this.txtOpisPregled.TabIndex = 81;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(27, 276);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(105, 22);
            this.label22.TabIndex = 80;
            this.label22.Text = "Opis pregleda";
            // 
            // txtDatumPregled
            // 
            this.txtDatumPregled.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtDatumPregled.Location = new System.Drawing.Point(349, 239);
            this.txtDatumPregled.Name = "txtDatumPregled";
            this.txtDatumPregled.Size = new System.Drawing.Size(121, 28);
            this.txtDatumPregled.TabIndex = 79;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label21.Location = new System.Drawing.Point(222, 241);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(119, 22);
            this.label21.TabIndex = 77;
            this.label21.Text = "Danasnji datum";
            // 
            // txtPovijestPregled
            // 
            this.txtPovijestPregled.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPovijestPregled.Location = new System.Drawing.Point(142, 110);
            this.txtPovijestPregled.Name = "txtPovijestPregled";
            this.txtPovijestPregled.Size = new System.Drawing.Size(500, 28);
            this.txtPovijestPregled.TabIndex = 76;
            // 
            // cbDatumPregled
            // 
            this.cbDatumPregled.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbDatumPregled.FormattingEnabled = true;
            this.cbDatumPregled.Location = new System.Drawing.Point(349, 69);
            this.cbDatumPregled.Name = "cbDatumPregled";
            this.cbDatumPregled.Size = new System.Drawing.Size(121, 28);
            this.cbDatumPregled.TabIndex = 75;
            // 
            // txtPorukaPregled
            // 
            this.txtPorukaPregled.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPorukaPregled.Location = new System.Drawing.Point(142, 158);
            this.txtPorukaPregled.Name = "txtPorukaPregled";
            this.txtPorukaPregled.Size = new System.Drawing.Size(500, 28);
            this.txtPorukaPregled.TabIndex = 74;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(27, 159);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(116, 22);
            this.label19.TabIndex = 73;
            this.label19.Text = "Sljedeci pregled";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(27, 112);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 22);
            this.label16.TabIndex = 69;
            this.label16.Text = "Povijest bolesti";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label17.Location = new System.Drawing.Point(222, 71);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(121, 22);
            this.label17.TabIndex = 67;
            this.label17.Text = "Datum pregleda";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.PowderBlue;
            this.label18.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(42, 32);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(600, 26);
            this.label18.TabIndex = 41;
            this.label18.Text = "Pregled pacijenta";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnPosaljiPoruku
            // 
            this.btnPosaljiPoruku.AutoSize = true;
            this.btnPosaljiPoruku.BackColor = System.Drawing.Color.PowderBlue;
            this.btnPosaljiPoruku.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnPosaljiPoruku.ForeColor = System.Drawing.Color.White;
            this.btnPosaljiPoruku.Location = new System.Drawing.Point(305, 192);
            this.btnPosaljiPoruku.Name = "btnPosaljiPoruku";
            this.btnPosaljiPoruku.Size = new System.Drawing.Size(96, 32);
            this.btnPosaljiPoruku.TabIndex = 66;
            this.btnPosaljiPoruku.Text = "Obavijesti";
            this.btnPosaljiPoruku.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPosaljiPoruku.UseVisualStyleBackColor = false;
            this.btnPosaljiPoruku.Click += new System.EventHandler(this.btnPosaljiPoruku_Click);
            // 
            // dataGridViewCekanje
            // 
            this.dataGridViewCekanje.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.CornflowerBlue;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCekanje.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewCekanje.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LavenderBlush;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCekanje.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewCekanje.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewCekanje.Name = "dataGridViewCekanje";
            this.dataGridViewCekanje.Size = new System.Drawing.Size(689, 376);
            this.dataGridViewCekanje.TabIndex = 41;
            // 
            // cbCekanjeUredi
            // 
            this.cbCekanjeUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbCekanjeUredi.FormattingEnabled = true;
            this.cbCekanjeUredi.Items.AddRange(new object[] {
            "True",
            "False"});
            this.cbCekanjeUredi.Location = new System.Drawing.Point(468, 291);
            this.cbCekanjeUredi.Name = "cbCekanjeUredi";
            this.cbCekanjeUredi.Size = new System.Drawing.Size(121, 28);
            this.cbCekanjeUredi.TabIndex = 34;
            this.cbCekanjeUredi.Text = "-Odabir-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(361, 293);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 22);
            this.label4.TabIndex = 33;
            this.label4.Text = "Čekanje";
            // 
            // txtIdUredi
            // 
            this.txtIdUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtIdUredi.Location = new System.Drawing.Point(203, 294);
            this.txtIdUredi.Name = "txtIdUredi";
            this.txtIdUredi.Size = new System.Drawing.Size(121, 28);
            this.txtIdUredi.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(63, 293);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 22);
            this.label6.TabIndex = 32;
            this.label6.Text = "Id";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.PowderBlue;
            this.label7.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(42, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(600, 26);
            this.label7.TabIndex = 31;
            this.label7.Text = "Uredivanje pacijenta";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnSpremiUredenog
            // 
            this.btnSpremiUredenog.AutoSize = true;
            this.btnSpremiUredenog.BackColor = System.Drawing.Color.PowderBlue;
            this.btnSpremiUredenog.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSpremiUredenog.ForeColor = System.Drawing.Color.White;
            this.btnSpremiUredenog.Location = new System.Drawing.Point(308, 341);
            this.btnSpremiUredenog.Name = "btnSpremiUredenog";
            this.btnSpremiUredenog.Size = new System.Drawing.Size(75, 32);
            this.btnSpremiUredenog.TabIndex = 35;
            this.btnSpremiUredenog.Text = "Spremi";
            this.btnSpremiUredenog.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSpremiUredenog.UseVisualStyleBackColor = false;
            this.btnSpremiUredenog.Click += new System.EventHandler(this.btnSpremiUredenog_Click);
            // 
            // txtMobitelUredi
            // 
            this.txtMobitelUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtMobitelUredi.Location = new System.Drawing.Point(468, 241);
            this.txtMobitelUredi.Name = "txtMobitelUredi";
            this.txtMobitelUredi.Size = new System.Drawing.Size(121, 28);
            this.txtMobitelUredi.TabIndex = 34;
            // 
            // txtGodinaUredi
            // 
            this.txtGodinaUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtGodinaUredi.Location = new System.Drawing.Point(468, 85);
            this.txtGodinaUredi.Name = "txtGodinaUredi";
            this.txtGodinaUredi.Size = new System.Drawing.Size(121, 28);
            this.txtGodinaUredi.TabIndex = 34;
            // 
            // txtEmailUredi
            // 
            this.txtEmailUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtEmailUredi.Location = new System.Drawing.Point(203, 241);
            this.txtEmailUredi.Name = "txtEmailUredi";
            this.txtEmailUredi.Size = new System.Drawing.Size(121, 28);
            this.txtEmailUredi.TabIndex = 34;
            // 
            // txtAdresaUredi
            // 
            this.txtAdresaUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtAdresaUredi.Location = new System.Drawing.Point(203, 189);
            this.txtAdresaUredi.Name = "txtAdresaUredi";
            this.txtAdresaUredi.Size = new System.Drawing.Size(121, 28);
            this.txtAdresaUredi.TabIndex = 34;
            // 
            // txtPrezimeUredi
            // 
            this.txtPrezimeUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPrezimeUredi.Location = new System.Drawing.Point(203, 137);
            this.txtPrezimeUredi.Name = "txtPrezimeUredi";
            this.txtPrezimeUredi.Size = new System.Drawing.Size(121, 28);
            this.txtPrezimeUredi.TabIndex = 34;
            // 
            // txtImeUredi
            // 
            this.txtImeUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtImeUredi.Location = new System.Drawing.Point(203, 85);
            this.txtImeUredi.Name = "txtImeUredi";
            this.txtImeUredi.Size = new System.Drawing.Size(121, 28);
            this.txtImeUredi.TabIndex = 34;
            // 
            // cbKrvUredi
            // 
            this.cbKrvUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbKrvUredi.FormattingEnabled = true;
            this.cbKrvUredi.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.cbKrvUredi.Location = new System.Drawing.Point(469, 189);
            this.cbKrvUredi.Name = "cbKrvUredi";
            this.cbKrvUredi.Size = new System.Drawing.Size(121, 28);
            this.cbKrvUredi.TabIndex = 34;
            this.cbKrvUredi.Text = "-Odabir-";
            // 
            // cbSpolUredi
            // 
            this.cbSpolUredi.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbSpolUredi.FormattingEnabled = true;
            this.cbSpolUredi.Items.AddRange(new object[] {
            "Muški",
            "Ženski"});
            this.cbSpolUredi.Location = new System.Drawing.Point(468, 137);
            this.cbSpolUredi.Name = "cbSpolUredi";
            this.cbSpolUredi.Size = new System.Drawing.Size(121, 28);
            this.cbSpolUredi.TabIndex = 34;
            this.cbSpolUredi.Text = "-Odabir-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(361, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 22);
            this.label8.TabIndex = 33;
            this.label8.Text = "Broj mobitela";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(361, 189);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 22);
            this.label9.TabIndex = 33;
            this.label9.Text = "Krvna grupa";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(361, 137);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 22);
            this.label10.TabIndex = 33;
            this.label10.Text = "Spol";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(361, 85);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 22);
            this.label11.TabIndex = 33;
            this.label11.Text = "Godina";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(63, 189);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(134, 22);
            this.label12.TabIndex = 32;
            this.label12.Text = "Adresa stanovanja";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(63, 241);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 22);
            this.label13.TabIndex = 32;
            this.label13.Text = "Email adresa";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(63, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 22);
            this.label14.TabIndex = 32;
            this.label14.Text = "Prezime";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(63, 85);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 22);
            this.label15.TabIndex = 32;
            this.label15.Text = "Ime";
            // 
            // btnListaPacijenata
            // 
            this.btnListaPacijenata.BackColor = System.Drawing.Color.PowderBlue;
            this.btnListaPacijenata.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnListaPacijenata.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnListaPacijenata.ForeColor = System.Drawing.Color.White;
            this.btnListaPacijenata.Location = new System.Drawing.Point(41, 208);
            this.btnListaPacijenata.Name = "btnListaPacijenata";
            this.btnListaPacijenata.Size = new System.Drawing.Size(120, 30);
            this.btnListaPacijenata.TabIndex = 32;
            this.btnListaPacijenata.Text = "Lista Pacijenata";
            this.btnListaPacijenata.UseVisualStyleBackColor = false;
            this.btnListaPacijenata.Click += new System.EventHandler(this.btnListaPacijenata_Click);
            // 
            // lblNavigacija
            // 
            this.lblNavigacija.AutoSize = true;
            this.lblNavigacija.BackColor = System.Drawing.Color.PowderBlue;
            this.lblNavigacija.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblNavigacija.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblNavigacija.Location = new System.Drawing.Point(27, 98);
            this.lblNavigacija.Name = "lblNavigacija";
            this.lblNavigacija.Size = new System.Drawing.Size(149, 28);
            this.lblNavigacija.TabIndex = 36;
            this.lblNavigacija.Text = "NAVIGACIJA";
            // 
            // btnListaČekanja
            // 
            this.btnListaČekanja.BackColor = System.Drawing.Color.PowderBlue;
            this.btnListaČekanja.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnListaČekanja.ForeColor = System.Drawing.Color.White;
            this.btnListaČekanja.Location = new System.Drawing.Point(41, 257);
            this.btnListaČekanja.Name = "btnListaČekanja";
            this.btnListaČekanja.Size = new System.Drawing.Size(120, 30);
            this.btnListaČekanja.TabIndex = 37;
            this.btnListaČekanja.Text = "Lista Čekanja";
            this.btnListaČekanja.UseVisualStyleBackColor = false;
            this.btnListaČekanja.Click += new System.EventHandler(this.btnListaČekanja_Click);
            // 
            // pictureBoxGif
            // 
            this.pictureBoxGif.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxGif.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxGif.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGif.Image")));
            this.pictureBoxGif.Location = new System.Drawing.Point(41, 392);
            this.pictureBoxGif.Name = "pictureBoxGif";
            this.pictureBoxGif.Size = new System.Drawing.Size(120, 82);
            this.pictureBoxGif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxGif.TabIndex = 38;
            this.pictureBoxGif.TabStop = false;
            // 
            // pictureBoxVuv
            // 
            this.pictureBoxVuv.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxVuv.Image")));
            this.pictureBoxVuv.Location = new System.Drawing.Point(229, 98);
            this.pictureBoxVuv.Name = "pictureBoxVuv";
            this.pictureBoxVuv.Size = new System.Drawing.Size(689, 376);
            this.pictureBoxVuv.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxVuv.TabIndex = 39;
            this.pictureBoxVuv.TabStop = false;
            // 
            // panelListaPacijenata
            // 
            this.panelListaPacijenata.Controls.Add(this.panelDodajPacijenta);
            this.panelListaPacijenata.Controls.Add(this.dataGridViewPacijenti);
            this.panelListaPacijenata.Controls.Add(this.Dodaj);
            this.panelListaPacijenata.Location = new System.Drawing.Point(229, 98);
            this.panelListaPacijenata.Name = "panelListaPacijenata";
            this.panelListaPacijenata.Size = new System.Drawing.Size(689, 376);
            this.panelListaPacijenata.TabIndex = 10;
            // 
            // panelDodajPacijenta
            // 
            this.panelDodajPacijenta.Controls.Add(this.cbCekanje);
            this.panelDodajPacijenta.Controls.Add(this.label20);
            this.panelDodajPacijenta.Controls.Add(this.btnSpremiNovog);
            this.panelDodajPacijenta.Controls.Add(this.txtMobitel);
            this.panelDodajPacijenta.Controls.Add(this.lblId);
            this.panelDodajPacijenta.Controls.Add(this.txtId);
            this.panelDodajPacijenta.Controls.Add(this.txtGodina);
            this.panelDodajPacijenta.Controls.Add(this.txtEmail);
            this.panelDodajPacijenta.Controls.Add(this.label3);
            this.panelDodajPacijenta.Controls.Add(this.txtAdresa);
            this.panelDodajPacijenta.Controls.Add(this.txtPrezime);
            this.panelDodajPacijenta.Controls.Add(this.txtIme);
            this.panelDodajPacijenta.Controls.Add(this.cbKrv);
            this.panelDodajPacijenta.Controls.Add(this.cbSpol);
            this.panelDodajPacijenta.Controls.Add(this.lblMobitel);
            this.panelDodajPacijenta.Controls.Add(this.lblKrv);
            this.panelDodajPacijenta.Controls.Add(this.lblSpol);
            this.panelDodajPacijenta.Controls.Add(this.lblGodina);
            this.panelDodajPacijenta.Controls.Add(this.lblAdresa);
            this.panelDodajPacijenta.Controls.Add(this.lblEmail);
            this.panelDodajPacijenta.Controls.Add(this.lblPrezime);
            this.panelDodajPacijenta.Controls.Add(this.lblIme);
            this.panelDodajPacijenta.Location = new System.Drawing.Point(0, 0);
            this.panelDodajPacijenta.Name = "panelDodajPacijenta";
            this.panelDodajPacijenta.Size = new System.Drawing.Size(689, 376);
            this.panelDodajPacijenta.TabIndex = 40;
            // 
            // cbCekanje
            // 
            this.cbCekanje.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbCekanje.FormattingEnabled = true;
            this.cbCekanje.Items.AddRange(new object[] {
            "True",
            "False"});
            this.cbCekanje.Location = new System.Drawing.Point(469, 291);
            this.cbCekanje.Name = "cbCekanje";
            this.cbCekanje.Size = new System.Drawing.Size(121, 28);
            this.cbCekanje.TabIndex = 25;
            this.cbCekanje.Text = "-Odabir-";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(361, 293);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 22);
            this.label20.TabIndex = 23;
            this.label20.Text = "Čekanje";
            // 
            // btnSpremiNovog
            // 
            this.btnSpremiNovog.AutoSize = true;
            this.btnSpremiNovog.BackColor = System.Drawing.Color.PowderBlue;
            this.btnSpremiNovog.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnSpremiNovog.ForeColor = System.Drawing.Color.White;
            this.btnSpremiNovog.Location = new System.Drawing.Point(308, 338);
            this.btnSpremiNovog.Name = "btnSpremiNovog";
            this.btnSpremiNovog.Size = new System.Drawing.Size(75, 32);
            this.btnSpremiNovog.TabIndex = 26;
            this.btnSpremiNovog.Text = "Spremi";
            this.btnSpremiNovog.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSpremiNovog.UseVisualStyleBackColor = false;
            this.btnSpremiNovog.Click += new System.EventHandler(this.btnSpremiNovog_Click);
            // 
            // txtMobitel
            // 
            this.txtMobitel.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtMobitel.Location = new System.Drawing.Point(468, 241);
            this.txtMobitel.Name = "txtMobitel";
            this.txtMobitel.Size = new System.Drawing.Size(121, 28);
            this.txtMobitel.TabIndex = 25;
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblId.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblId.Location = new System.Drawing.Point(64, 293);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(24, 22);
            this.lblId.TabIndex = 22;
            this.lblId.Text = "Id";
            // 
            // txtId
            // 
            this.txtId.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtId.Location = new System.Drawing.Point(203, 291);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(121, 28);
            this.txtId.TabIndex = 24;
            // 
            // txtGodina
            // 
            this.txtGodina.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtGodina.Location = new System.Drawing.Point(468, 85);
            this.txtGodina.Name = "txtGodina";
            this.txtGodina.Size = new System.Drawing.Size(121, 28);
            this.txtGodina.TabIndex = 25;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtEmail.Location = new System.Drawing.Point(203, 241);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(121, 28);
            this.txtEmail.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.PowderBlue;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(43, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(600, 26);
            this.label3.TabIndex = 21;
            this.label3.Text = "Dodavanje pacijenta";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // txtAdresa
            // 
            this.txtAdresa.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtAdresa.Location = new System.Drawing.Point(203, 189);
            this.txtAdresa.Name = "txtAdresa";
            this.txtAdresa.Size = new System.Drawing.Size(121, 28);
            this.txtAdresa.TabIndex = 24;
            // 
            // txtPrezime
            // 
            this.txtPrezime.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtPrezime.Location = new System.Drawing.Point(203, 137);
            this.txtPrezime.Name = "txtPrezime";
            this.txtPrezime.Size = new System.Drawing.Size(121, 28);
            this.txtPrezime.TabIndex = 24;
            // 
            // txtIme
            // 
            this.txtIme.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtIme.Location = new System.Drawing.Point(203, 85);
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(121, 28);
            this.txtIme.TabIndex = 24;
            // 
            // cbKrv
            // 
            this.cbKrv.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbKrv.FormattingEnabled = true;
            this.cbKrv.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.cbKrv.Location = new System.Drawing.Point(469, 189);
            this.cbKrv.Name = "cbKrv";
            this.cbKrv.Size = new System.Drawing.Size(121, 28);
            this.cbKrv.TabIndex = 25;
            this.cbKrv.Text = "-Odabir-";
            // 
            // cbSpol
            // 
            this.cbSpol.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.cbSpol.FormattingEnabled = true;
            this.cbSpol.Items.AddRange(new object[] {
            "Muški",
            "Ženski"});
            this.cbSpol.Location = new System.Drawing.Point(468, 137);
            this.cbSpol.Name = "cbSpol";
            this.cbSpol.Size = new System.Drawing.Size(121, 28);
            this.cbSpol.TabIndex = 25;
            this.cbSpol.Text = "-Odabir-";
            // 
            // lblMobitel
            // 
            this.lblMobitel.AutoSize = true;
            this.lblMobitel.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblMobitel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblMobitel.Location = new System.Drawing.Point(361, 241);
            this.lblMobitel.Name = "lblMobitel";
            this.lblMobitel.Size = new System.Drawing.Size(101, 22);
            this.lblMobitel.TabIndex = 23;
            this.lblMobitel.Text = "Broj mobitela";
            // 
            // lblKrv
            // 
            this.lblKrv.AutoSize = true;
            this.lblKrv.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblKrv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblKrv.Location = new System.Drawing.Point(361, 189);
            this.lblKrv.Name = "lblKrv";
            this.lblKrv.Size = new System.Drawing.Size(97, 22);
            this.lblKrv.TabIndex = 23;
            this.lblKrv.Text = "Krvna grupa";
            // 
            // lblSpol
            // 
            this.lblSpol.AutoSize = true;
            this.lblSpol.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblSpol.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblSpol.Location = new System.Drawing.Point(361, 137);
            this.lblSpol.Name = "lblSpol";
            this.lblSpol.Size = new System.Drawing.Size(40, 22);
            this.lblSpol.TabIndex = 23;
            this.lblSpol.Text = "Spol";
            // 
            // lblGodina
            // 
            this.lblGodina.AutoSize = true;
            this.lblGodina.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblGodina.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblGodina.Location = new System.Drawing.Point(361, 85);
            this.lblGodina.Name = "lblGodina";
            this.lblGodina.Size = new System.Drawing.Size(60, 22);
            this.lblGodina.TabIndex = 23;
            this.lblGodina.Text = "Godina";
            // 
            // lblAdresa
            // 
            this.lblAdresa.AutoSize = true;
            this.lblAdresa.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblAdresa.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblAdresa.Location = new System.Drawing.Point(63, 189);
            this.lblAdresa.Name = "lblAdresa";
            this.lblAdresa.Size = new System.Drawing.Size(134, 22);
            this.lblAdresa.TabIndex = 22;
            this.lblAdresa.Text = "Adresa stanovanja";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblEmail.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblEmail.Location = new System.Drawing.Point(63, 241);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(98, 22);
            this.lblEmail.TabIndex = 22;
            this.lblEmail.Text = "Email adresa";
            // 
            // lblPrezime
            // 
            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPrezime.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPrezime.Location = new System.Drawing.Point(63, 137);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Size = new System.Drawing.Size(66, 22);
            this.lblPrezime.TabIndex = 22;
            this.lblPrezime.Text = "Prezime";
            // 
            // lblIme
            // 
            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblIme.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblIme.Location = new System.Drawing.Point(63, 85);
            this.lblIme.Name = "lblIme";
            this.lblIme.Size = new System.Drawing.Size(36, 22);
            this.lblIme.TabIndex = 22;
            this.lblIme.Text = "Ime";
            // 
            // dataGridViewPacijenti
            // 
            this.dataGridViewPacijenti.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPacijenti.BackgroundColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Palatino Linotype", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.LightCoral;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewPacijenti.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewPacijenti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LavenderBlush;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Palatino Linotype", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.PowderBlue;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewPacijenti.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewPacijenti.GridColor = System.Drawing.Color.MistyRose;
            this.dataGridViewPacijenti.Location = new System.Drawing.Point(0, 32);
            this.dataGridViewPacijenti.Name = "dataGridViewPacijenti";
            this.dataGridViewPacijenti.Size = new System.Drawing.Size(689, 344);
            this.dataGridViewPacijenti.TabIndex = 11;
            // 
            // Dodaj
            // 
            this.Dodaj.AutoSize = true;
            this.Dodaj.BackColor = System.Drawing.Color.PowderBlue;
            this.Dodaj.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Dodaj.ForeColor = System.Drawing.Color.White;
            this.Dodaj.Location = new System.Drawing.Point(0, 0);
            this.Dodaj.Name = "Dodaj";
            this.Dodaj.Size = new System.Drawing.Size(135, 32);
            this.Dodaj.TabIndex = 12;
            this.Dodaj.Text = "Dodaj Pacijenta";
            this.Dodaj.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Dodaj.UseVisualStyleBackColor = false;
            this.Dodaj.Click += new System.EventHandler(this.Dodaj_Click);
            // 
            // btnPocetna
            // 
            this.btnPocetna.BackColor = System.Drawing.Color.PowderBlue;
            this.btnPocetna.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnPocetna.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnPocetna.ForeColor = System.Drawing.Color.White;
            this.btnPocetna.Location = new System.Drawing.Point(41, 161);
            this.btnPocetna.Name = "btnPocetna";
            this.btnPocetna.Size = new System.Drawing.Size(120, 30);
            this.btnPocetna.TabIndex = 31;
            this.btnPocetna.Text = "Početna";
            this.btnPocetna.UseVisualStyleBackColor = false;
            this.btnPocetna.Click += new System.EventHandler(this.btnPocetna_Click);
            // 
            // btnOBolnici
            // 
            this.btnOBolnici.BackColor = System.Drawing.Color.PowderBlue;
            this.btnOBolnici.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnOBolnici.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOBolnici.ForeColor = System.Drawing.Color.White;
            this.btnOBolnici.Location = new System.Drawing.Point(41, 304);
            this.btnOBolnici.Name = "btnOBolnici";
            this.btnOBolnici.Size = new System.Drawing.Size(120, 30);
            this.btnOBolnici.TabIndex = 34;
            this.btnOBolnici.Text = "O bolnici";
            this.btnOBolnici.UseVisualStyleBackColor = false;
            this.btnOBolnici.Click += new System.EventHandler(this.btnOBolnici_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(930, 562);
            this.Controls.Add(this.panelOBolnici);
            this.Controls.Add(this.panelUrediPacijenta);
            this.Controls.Add(this.btnOBolnici);
            this.Controls.Add(this.btnPocetna);
            this.Controls.Add(this.panelListaPacijenata);
            this.Controls.Add(this.pictureBoxVuv);
            this.Controls.Add(this.pictureBoxGif);
            this.Controls.Add(this.btnListaČekanja);
            this.Controls.Add(this.lblNavigacija);
            this.Controls.Add(this.btnListaPacijenata);
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.panelTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKriz)).EndInit();
            this.panelBottom.ResumeLayout(false);
            this.panelUrediPacijenta.ResumeLayout(false);
            this.panelUrediPacijenta.PerformLayout();
            this.panelListaCekanja.ResumeLayout(false);
            this.panelPregled.ResumeLayout(false);
            this.panelPregled.PerformLayout();
            this.panelOBolnici.ResumeLayout(false);
            this.panelOBolnici.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCekanje)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVuv)).EndInit();
            this.panelListaPacijenata.ResumeLayout(false);
            this.panelListaPacijenata.PerformLayout();
            this.panelDodajPacijenta.ResumeLayout(false);
            this.panelDodajPacijenta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPacijenti)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panelTop;
        private Label Zatvori;
        private PictureBox pictureBoxKriz;
        private Label label2;
        private Label label1;
        private Panel panelBottom;
        private Label label5;
        private Button btnListaPacijenata;
        private Label lblNavigacija;
        private Button btnListaČekanja;
        private PictureBox pictureBoxGif;
        private PictureBox pictureBoxVuv;
        private Panel panelListaPacijenata;
        private Button Dodaj;
        private DataGridView dataGridViewPacijenti;
        private Panel panelListaCekanja;
        private DataGridView dataGridViewCekanje;
        private Button btnPocetna;
        private Button btnOBolnici;
        private Panel panelDodajPacijenta;
        private ComboBox cbCekanje;
        private Label label20;
        private Button btnSpremiNovog;
        private TextBox txtMobitel;
        private Label lblId;
        private TextBox txtId;
        private TextBox txtGodina;
        private TextBox txtEmail;
        private Label label3;
        private TextBox txtAdresa;
        private TextBox txtPrezime;
        private TextBox txtIme;
        private ComboBox cbKrv;
        private ComboBox cbSpol;
        private Label lblMobitel;
        private Label lblKrv;
        private Label lblSpol;
        private Label lblGodina;
        private Label lblAdresa;
        private Label lblEmail;
        private Label lblPrezime;
        private Label lblIme;
        private Panel panelPregled;
        private Button btnSpremiPregled;
        private TextBox txtOpisPregled;
        private Label label22;
        private TextBox txtDatumPregled;
        private Label label21;
        private TextBox txtPovijestPregled;
        private ComboBox cbDatumPregled;
        private TextBox txtPorukaPregled;
        private Label label19;
        private Label label16;
        private Label label17;
        private Label label18;
        private Button btnPosaljiPoruku;
        private Panel panelUrediPacijenta;
        private ComboBox cbCekanjeUredi;
        private Label label4;
        private TextBox txtIdUredi;
        private Label label6;
        private Label label7;
        private Button btnSpremiUredenog;
        private TextBox txtMobitelUredi;
        private TextBox txtGodinaUredi;
        private TextBox txtEmailUredi;
        private TextBox txtAdresaUredi;
        private TextBox txtPrezimeUredi;
        private TextBox txtImeUredi;
        private ComboBox cbKrvUredi;
        private ComboBox cbSpolUredi;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Panel panelOBolnici;
        private TextBox textBox1;
        private Label label23;
    }
}
