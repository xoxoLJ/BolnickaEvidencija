﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Net;
using System.Net.Mail;

namespace Bolnička_evidencija
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            dataGridViewPacijenti.AutoGenerateColumns = false;
            dataGridViewCekanje.AutoGenerateColumns = false;

            dataGridViewPacijenti.CellClick += dataGridViewPacijenti_CellClick;
            dataGridViewCekanje.CellClick += dataGridViewCekanje_CellClick;

            DataGridViewTextBoxColumn stupacIme = new DataGridViewTextBoxColumn();
            stupacIme.Name = "stupacIme";
            stupacIme.DataPropertyName = "Ime";
            stupacIme.HeaderText = "Ime";
            dataGridViewPacijenti.Columns.Add(stupacIme);

            DataGridViewTextBoxColumn stupacImePregled = new DataGridViewTextBoxColumn();
            stupacImePregled.Name = "stupacImePregled";
            stupacImePregled.DataPropertyName = "Ime";
            stupacImePregled.HeaderText = "Ime";
            dataGridViewCekanje.Columns.Add(stupacImePregled);

            DataGridViewTextBoxColumn stupacPrezime = new DataGridViewTextBoxColumn();
            stupacPrezime.Name = "stupacPrezime";
            stupacPrezime.DataPropertyName = "Prezime";
            stupacPrezime.HeaderText = "Prezime";
            dataGridViewPacijenti.Columns.Add(stupacPrezime);

            DataGridViewTextBoxColumn stupacPrezimePregled = new DataGridViewTextBoxColumn();
            stupacPrezimePregled.Name = "stupacPrezimePregled";
            stupacPrezimePregled.DataPropertyName = "Prezime";
            stupacPrezimePregled.HeaderText = "Prezime";
            dataGridViewCekanje.Columns.Add(stupacPrezimePregled);

            DataGridViewTextBoxColumn stupacAdresaPregled = new DataGridViewTextBoxColumn();
            stupacAdresaPregled.Name = "stupacAdresaPregled";
            stupacAdresaPregled.DataPropertyName = "Adresa";
            stupacAdresaPregled.HeaderText = "Adresa";
            dataGridViewCekanje.Columns.Add(stupacAdresaPregled);

            DataGridViewTextBoxColumn stupacEmailPregled = new DataGridViewTextBoxColumn();
            stupacEmailPregled.Name = "stupacEmailPregled";
            stupacEmailPregled.DataPropertyName = "Email";
            stupacEmailPregled.HeaderText = "Email";
            dataGridViewCekanje.Columns.Add(stupacEmailPregled);

            DataGridViewTextBoxColumn stupacGodinaPregled = new DataGridViewTextBoxColumn();
            stupacGodinaPregled.Name = "stupacGodinaPregled";
            stupacGodinaPregled.DataPropertyName = "Godina";
            stupacGodinaPregled.HeaderText = "Godina";
            dataGridViewCekanje.Columns.Add(stupacGodinaPregled);

            DataGridViewTextBoxColumn stupacSpolPregled = new DataGridViewTextBoxColumn();
            stupacSpolPregled.Name = "stupacSpolPregled";
            stupacSpolPregled.DataPropertyName = "Spol";
            stupacSpolPregled.HeaderText = "Spol";
            dataGridViewCekanje.Columns.Add(stupacSpolPregled);

            DataGridViewTextBoxColumn stupacKrvnaGrupaPregled = new DataGridViewTextBoxColumn();
            stupacKrvnaGrupaPregled.Name = "stupacKrvnaGrupaPregled";
            stupacKrvnaGrupaPregled.DataPropertyName = "Krvna Grupa";
            stupacKrvnaGrupaPregled.HeaderText = "Krvna Grupa";
            dataGridViewCekanje.Columns.Add(stupacKrvnaGrupaPregled);

            DataGridViewTextBoxColumn stupacMobitelPregled = new DataGridViewTextBoxColumn();
            stupacMobitelPregled.Name = "stupacSpolPregled";
            stupacMobitelPregled.DataPropertyName = "Broj Mobitela";
            stupacMobitelPregled.HeaderText = "Broj Mobitela";
            dataGridViewCekanje.Columns.Add(stupacMobitelPregled);

            DataGridViewButtonColumn stupacUredi = new DataGridViewButtonColumn();
            stupacUredi.Name = "stupacUredi";
            stupacUredi.HeaderText = "Uredi";
            stupacUredi.Text = "O";
            stupacUredi.UseColumnTextForButtonValue = true;
            stupacUredi.Width = 100;
            dataGridViewPacijenti.Columns.Add(stupacUredi);

            DataGridViewButtonColumn stupacIzbrisi = new DataGridViewButtonColumn();
            stupacIzbrisi.Name = "stupacIzbrisi";
            stupacIzbrisi.HeaderText = "Izbrisi";
            stupacIzbrisi.Text = "X";
            stupacIzbrisi.UseColumnTextForButtonValue = true;
            stupacIzbrisi.Width = 100;
            dataGridViewPacijenti.Columns.Add(stupacIzbrisi);

            DataGridViewButtonColumn stupacPregled = new DataGridViewButtonColumn();
            stupacPregled.Name = "stupacPregled";
            stupacPregled.HeaderText = "Pregled";
            stupacPregled.Text = "PREGLED";
            stupacPregled.UseColumnTextForButtonValue = true;
            stupacPregled.Width = 100;
            dataGridViewCekanje.Columns.Add(stupacPregled);

            Osvjezi_Podatke();
        }

        private void Osvjezi_Podatke()
        {
            // Clearing lists may not be necessary, evaluate if this is required for your use case.
            PacijentServis.ListaPacijenata.Clear();
            PacijentServis.ListaCekanja.Clear();
            PacijentServis.ListaPovijesti.Clear();

            string connectionString = "Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;";

            using (DbConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Retrieve Pacijenti data
                using (DbCommand command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT * FROM Jovanovic_Pacijenti";
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Pacijent pacijent = GetPacijentFromReader(reader);
                            PacijentServis.ListaPacijenata.Add(pacijent);

                            if (pacijent.cekanje)
                            {
                                PacijentServis.ListaCekanja.Add(pacijent);
                            }
                        }
                    }
                }

                // Retrieve PovijestBolesti data
                using (DbCommand command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT * FROM Jovanovic_PovijestBolesti";
                    using (DbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            PacijentPovijest pacijentPovijest = GetPacijentPovijestFromReader(reader);
                            PacijentServis.ListaPovijesti.Add(pacijentPovijest);
                        }
                    }
                }

                connection.Close();
            }

            // Update DataGridViews
            UpdateDataGridView(dataGridViewPacijenti, PacijentServis.ListaPacijenata);
            UpdateDataGridViewCekanje(dataGridViewCekanje, PacijentServis.ListaCekanja);
        }

        private Pacijent GetPacijentFromReader(DbDataReader reader)
        {
            return new Pacijent()
            {
                id = (int)reader["Id"],
                ime = (string)reader["Ime"],
                prezime = (string)reader["Prezime"],
                adresaStanovanja = (string)reader["Adresa"],
                emailAdresa = (string)reader["Email"],
                godina = (int)reader["Godina"],
                spol = (string)reader["Spol"],
                krvnaGrupa = (string)reader["KrvnaGrupa"],
                brojMobitela = (string)reader["Mobitel"],
                cekanje = (bool)reader["Čekanje"]
            };
        }

        private PacijentPovijest GetPacijentPovijestFromReader(DbDataReader reader)
        {
            return new PacijentPovijest()
            {
                id = (int)reader["Id"],
                idPacijent = (int)reader["IdPacijent"],
                datum = (string)reader["Datum"],
                opis = (string)reader["Opis"]
            };
        }

        private void UpdateDataGridView(DataGridView dataGridView, List<Pacijent> lista)
        {
            dataGridView.Rows.Clear();
            foreach (Pacijent pacijent in lista)
            {
                DodajPacijenta(pacijent.ime, pacijent.prezime);
            }
        }

        private void UpdateDataGridViewCekanje(DataGridView dataGridView, List<Pacijent> lista)
        {
            dataGridView.Rows.Clear();
            foreach (Pacijent pacijent in lista)
            {
                DodajNaCekanje(pacijent.ime, pacijent.prezime, pacijent.adresaStanovanja, pacijent.emailAdresa, pacijent.godina, pacijent.spol, pacijent.krvnaGrupa, pacijent.brojMobitela);
            }
        }

        SqlConnection DbConnection = new SqlConnection(@"Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;");

        private void Zatvori_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            panelListaPacijenata.Visible = false;
            panelDodajPacijenta.Visible = false;
            panelUrediPacijenta.Visible=false;

            panelListaCekanja.Visible=false;
            panelPregled.Visible = false;
            panelOBolnici.Visible = false;
        }

        private void btnPocetna_Click(object sender, EventArgs e)
        {
            panelListaPacijenata.Visible = false;
            panelDodajPacijenta.Visible = false;
            panelUrediPacijenta.Visible = false;

            panelListaCekanja.Visible = false;
            panelPregled.Visible = false;
            panelOBolnici.Visible = false;
        }

        private void btnListaPacijenata_Click(object sender, EventArgs e)
        {
            panelListaPacijenata.Visible = true;
            panelDodajPacijenta.Visible = false;
            panelUrediPacijenta.Visible = false;

            panelListaCekanja.Visible = false;
            panelPregled.Visible = false;
            panelOBolnici.Visible = false;
        }

        private void DodajPacijenta(string ime, string prezime)
        {
            dataGridViewPacijenti.Rows.Add(ime, prezime);
        }

        private void dataGridViewPacijenti_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewCell cell = dataGridViewPacijenti.Rows[e.RowIndex].Cells[e.ColumnIndex];

                if (cell is DataGridViewButtonCell)
                {
                    switch (dataGridViewPacijenti.Columns[e.ColumnIndex].Name)
                    {
                        case "stupacUredi":
                            Uredi(e.RowIndex);
                            break;

                        case "stupacIzbrisi":
                            Izbrisi(e.RowIndex);
                            break;

                        default:
                            break;
                    }
                }
            }
        }
        private void Uredi(int rowIndex)
        {
            string ime = dataGridViewPacijenti.Rows[rowIndex].Cells["stupacIme"].Value.ToString();
            string prezime = dataGridViewPacijenti.Rows[rowIndex].Cells["stupacPrezime"].Value.ToString();

            if (ime != null && prezime != null)
            {
                UrediClick(ime, prezime);
            }
            else
            {
                MessageBox.Show("Podaci za pacijenta ne valjaju.");
            }
        }
        private void Izbrisi(int rowIndex)
        {
            string ime = dataGridViewPacijenti.Rows[rowIndex].Cells["stupacIme"].Value.ToString();
            string prezime = dataGridViewPacijenti.Rows[rowIndex].Cells["stupacPrezime"].Value.ToString();

            if (ime != null && prezime != null)
            {
                IzbrisiClick(ime, prezime);
            }
            else
            {
                MessageBox.Show("Podaci za pacijenta ne valjaju.");
            }
        }
        private void Dodaj_Click(object sender, EventArgs e)
        {
            panelDodajPacijenta.Visible = true;
        }

        private void btnSpremiNovog_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text);
                string ime = txtIme.Text;
                string prezime = txtPrezime.Text;
                string adresa = txtAdresa.Text;
                string email = txtEmail.Text;
                int godina = Convert.ToInt32(txtGodina.Text);
                string spol = cbSpol.Text;
                string krv = cbKrv.Text;
                string mobitel = txtMobitel.Text;

                bool cekanje;
                if (!bool.TryParse(cbCekanje.Text, out cekanje))
                {
                    MessageBox.Show("Nije moguće parsirati vrijednost Čekanje.");
                    return;
                }

                using (SqlConnection DbConnection = new SqlConnection(@"Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;"))
                {
                    DbConnection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = DbConnection;

                        cmd.CommandText = "INSERT INTO Jovanovic_Pacijenti (Id, Ime, Prezime, Adresa, Email, Godina, Spol, KrvnaGrupa, Mobitel, Čekanje) VALUES (@Id, @Ime, @Prezime, @Adresa, @Email, @Godina, @Spol, @Krv, @Mobitel, @Cekanje)";
                        cmd.Parameters.AddWithValue("@Id", id);
                        cmd.Parameters.AddWithValue("@Ime", ime);
                        cmd.Parameters.AddWithValue("@Prezime", prezime);
                        cmd.Parameters.AddWithValue("@Adresa", adresa);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Godina", godina);
                        cmd.Parameters.AddWithValue("@Spol", spol);
                        cmd.Parameters.AddWithValue("@Krv", krv);
                        cmd.Parameters.AddWithValue("@Mobitel", mobitel);
                        cmd.Parameters.AddWithValue("@Cekanje", cekanje);

                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Podaci spremljeni!");
                Osvjezi_Podatke();

                // Clear input fields after successful insertion
                txtId.Clear();
                txtIme.Clear();
                txtPrezime.Clear();
                txtAdresa.Clear();
                txtEmail.Clear();
                txtGodina.Clear();
                cbSpol.ResetText();
                cbKrv.ResetText();
                txtMobitel.Clear();
                cbCekanje.ResetText();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Nevaljani format podataka ili nevaljani id", ex.Message);
            }
        }

        private void UrediClick(string ime, string prezime)
        {
            try
            {
                panelDodajPacijenta.Visible = true;
                panelUrediPacijenta.Visible = true;

                using (SqlConnection DbConnection = new SqlConnection(@"Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;"))
                {
                    DbConnection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = DbConnection;

                        cmd.CommandText = "SELECT * FROM Jovanovic_Pacijenti WHERE Ime = @Ime AND Prezime = @Prezime";
                        cmd.Parameters.AddWithValue("@Ime", ime);
                        cmd.Parameters.AddWithValue("@Prezime", prezime);

                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            txtIdUredi.Text = reader["Id"].ToString();
                            txtImeUredi.Text = reader["Ime"].ToString();
                            txtPrezimeUredi.Text = reader["Prezime"].ToString();
                            txtAdresaUredi.Text = reader["Adresa"].ToString();
                            txtEmailUredi.Text = reader["Email"].ToString();
                            txtGodinaUredi.Text = reader["Godina"].ToString();
                            cbSpolUredi.Text = reader["Spol"].ToString();
                            cbKrvUredi.Text = reader["KrvnaGrupa"].ToString();
                            txtMobitelUredi.Text = reader["Mobitel"].ToString();
                            cbCekanjeUredi.Text = reader["Čekanje"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("Pacijent s navedenim ID-om nije pronađen.");
                        }

                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Greška prilikom dohvaćanja podataka za uređivanje: {ex.Message}");
            }
        }

        private void btnSpremiUredenog_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtIdUredi.Text);
                string ime = txtImeUredi.Text;
                string prezime = txtPrezimeUredi.Text;
                string adresa = txtAdresaUredi.Text;
                string email = txtEmailUredi.Text;
                int godina = Convert.ToInt32(txtGodinaUredi.Text);
                string spol = cbSpolUredi.Text;
                string krv = cbKrvUredi.Text;
                string mobitel = txtMobitelUredi.Text;

                bool cekanje;
                if (!bool.TryParse(cbCekanjeUredi.Text, out cekanje))
                {
                    MessageBox.Show("Nije moguće parsirati vrijednost Čekanje.");
                    return;
                }

                using (SqlConnection DbConnection = new SqlConnection(@"Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;"))
                {
                    DbConnection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = DbConnection;

                        cmd.CommandText = "UPDATE Jovanovic_Pacijenti SET Ime=@Ime, Prezime=@Prezime, Adresa=@Adresa, Email=@Email, Godina=@Godina, Spol=@Spol, KrvnaGrupa=@Krv, Mobitel=@Mobitel, Čekanje=@Cekanje WHERE Id=@Id";
                        cmd.Parameters.AddWithValue("@Id", id);
                        cmd.Parameters.AddWithValue("@Ime", ime);
                        cmd.Parameters.AddWithValue("@Prezime", prezime);
                        cmd.Parameters.AddWithValue("@Adresa", adresa);
                        cmd.Parameters.AddWithValue("@Email", email);
                        cmd.Parameters.AddWithValue("@Godina", godina);
                        cmd.Parameters.AddWithValue("@Spol", spol);
                        cmd.Parameters.AddWithValue("@Krv", krv);
                        cmd.Parameters.AddWithValue("@Mobitel", mobitel);
                        cmd.Parameters.AddWithValue("@Cekanje", cekanje);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Promjene su spremljene!");
                        }
                        else
                        {
                            MessageBox.Show("Nije bilo moguće spremiti promjene. Provjerite unesene podatke.");
                        }
                    }
                }

                MessageBox.Show("Podaci ažurirani!");
                Osvjezi_Podatke();

                // Clear input fields after successful update
                txtIdUredi.Clear();
                txtImeUredi.Clear();
                txtPrezimeUredi.Clear();
                txtAdresaUredi.Clear();
                txtEmailUredi.Clear();
                txtGodinaUredi.Clear();
                cbSpolUredi.ResetText();
                cbKrvUredi.ResetText();
                txtMobitelUredi.Clear();
                cbCekanjeUredi.ResetText();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Greška prilikom spremanja promjena: {ex.Message}");
            }
        }

        private void IzbrisiClick(string ime, string prezime)
        {
            try
            {
                using (SqlConnection DbConnection = new SqlConnection(@"Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;"))
                {
                    DbConnection.Open();

                    using (SqlCommand cmd = new SqlCommand())
                    {
                        cmd.Connection = DbConnection;

                        cmd.CommandText = "DELETE FROM Jovanovic_Pacijenti WHERE Ime = @Ime AND Prezime = @Prezime";
                        cmd.Parameters.AddWithValue("@Ime", ime);
                        cmd.Parameters.AddWithValue("@Prezime", prezime);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show($"Pacijent {ime} {prezime} je uspješno izbrisan iz baze podataka.");
                        }
                        else
                        {
                            MessageBox.Show($"Pacijent {ime} {prezime} nije pronađen u bazi podataka.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Greška prilikom brisanja pacijenta: {ex.Message}");
            }

            Osvjezi_Podatke();
        }

        private void btnListaČekanja_Click(object sender, EventArgs e)
        {
            panelListaPacijenata.Visible = true;
            panelDodajPacijenta.Visible = true;
            panelUrediPacijenta.Visible = true;

            panelListaCekanja.Visible = true;
            panelPregled.Visible = false;
            panelOBolnici.Visible = false;
        }

        private void DodajNaCekanje(string ime, string prezime, string adresa, string email, int godina, string spol, string krv, string mobitel)
        {
            dataGridViewCekanje.Rows.Add(ime, prezime, adresa, email, godina, spol, krv, mobitel);
        }

        private void dataGridViewCekanje_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewCell cell = dataGridViewCekanje.Rows[e.RowIndex].Cells[e.ColumnIndex];

                if (cell is DataGridViewButtonCell)
                {
                    switch (dataGridViewCekanje.Columns[e.ColumnIndex].Name)
                    {
                        case "stupacPregled":
                            Pregled(e.RowIndex);
                            break;

                        default:
                            break;
                    }
                }
            }
        }

        private void Pregled(int rowIndex)
        {
            string ime = dataGridViewCekanje.Rows[rowIndex].Cells["stupacImePregled"].Value.ToString();
            string prezime = dataGridViewCekanje.Rows[rowIndex].Cells["stupacPrezimePregled"].Value.ToString();

            if (ime != null && prezime != null)
            {
                PregledClick(ime, prezime);
            }
            else
            {
                MessageBox.Show("Podaci za pacijenta ne valjaju.");
            }
        }

        private string id;

        private void PregledClick(string ime, string prezime)
        {
            SqlConnection DbConnection = null;

            try
            {
                panelPregled.Visible = true;
                bool cekanje = false;

                DbConnection = new SqlConnection(@"Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;");
                DbConnection.Open();

                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = DbConnection;

                    // Update the Čekanje field using a parameterized query
                    cmd.CommandText = "UPDATE Jovanovic_Pacijenti SET Čekanje=@Cekanje WHERE Ime = @Ime AND Prezime = @Prezime";
                    cmd.Parameters.AddWithValue("@Cekanje", cekanje);
                    cmd.Parameters.AddWithValue("@Ime", ime);
                    cmd.Parameters.AddWithValue("@Prezime", prezime);

                    cmd.ExecuteNonQuery();

                    // Retrieve Id using parameterized query
                    cmd.CommandText = "SELECT Id FROM Jovanovic_Pacijenti WHERE Ime = @Ime AND Prezime = @Prezime";
                    SqlDataReader idReader = cmd.ExecuteReader();

                    id = string.Empty;

                    if (idReader.Read())
                    {
                        id = idReader["Id"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Pacijent s navedenim ID-om nije pronađen.");
                    }

                    idReader.Close();

                    using (SqlCommand cmdPovijest = new SqlCommand())
                    {
                        cmdPovijest.Connection = DbConnection;

                        cmdPovijest.CommandText = "SELECT DISTINCT Datum FROM Jovanovic_PovijestBolesti WHERE IdPacijent = @IdPacijent";
                        cmdPovijest.Parameters.AddWithValue("@IdPacijent", id);

                        SqlDataReader povijestReader = cmdPovijest.ExecuteReader();

                        cbDatumPregled.Items.Clear();  // Clear existing items in the ComboBox

                        while (povijestReader.Read())
                        {
                            string datum = povijestReader["Datum"].ToString();
                            cbDatumPregled.Items.Add(datum);
                        }

                        povijestReader.Close();
                    }

                    // Subscribe to the ComboBox's SelectedIndexChanged event here
                    cbDatumPregled.SelectedIndexChanged += (sender, e) =>
                    {
                        if (cbDatumPregled.SelectedIndex != -1)
                        {
                            string selectedDatum = cbDatumPregled.SelectedItem.ToString();

                            using (SqlCommand cmdOpis = new SqlCommand())
                            {
                                cmdOpis.Connection = DbConnection;

                                // Clear previous parameters
                                cmdOpis.Parameters.Clear();

                                // Retrieve Opis based on the selected Datum
                                cmdOpis.CommandText = "SELECT Opis FROM Jovanovic_PovijestBolesti WHERE IdPacijent = @IdPacijent AND Datum = @Datum";
                                cmdOpis.Parameters.AddWithValue("@IdPacijent", id);
                                cmdOpis.Parameters.AddWithValue("@Datum", selectedDatum);

                                SqlDataReader selectedDatumReader = cmdOpis.ExecuteReader();

                                if (selectedDatumReader.Read())
                                {
                                    txtPovijestPregled.Text = selectedDatumReader["Opis"].ToString();
                                }
                                else
                                {
                                    MessageBox.Show("Pacijent s navedenim Datumom nije pronađen.");
                                }

                                selectedDatumReader.Close();
                            }
                        }
                    };

                    txtDatumPregled.Text = DateTime.Now.ToString("dd.MM.yyyy.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Greška prilikom dohvaćanja podataka za pregled: {ex.Message}");
            }

            Osvjezi_Podatke();
        }
        private void btnPosaljiPoruku_Click(object sender, EventArgs e)
        {
            using(MailMessage mail = new MailMessage("leo.jovanovic02@gmail.com", "leo.jovanovic@vuv.hr", "Obavijest Projekta", txtPorukaPregled.Text))
            using (SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587))
            {
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("leo.jovanovic02@gmail.com", "urnv pheo zijv kzrc");
                smtp.EnableSsl = true;
                smtp.Send(mail);
            }

            //urnv pheo zijv kzrc
            /*try
            {
                string senderEmail = "leo.jovanovic@vuv.hr";
                string senderPassword = "KFB4L4st";
                string recipientEmail = "leo.jovanovic@vuv.hr";
                string smtpServer = "smtp-mail.outlook.com";
                int smtpPort = 587;

                SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort);
                smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);
                smtpClient.EnableSsl = true;
                //smtpClient.UseDefaultCredentials = false;
                //smtpClient.Timeout = 10000;

                MailMessage mailMessage = new MailMessage(senderEmail, recipientEmail, "Obavijest Projekta", txtPorukaPregled.Text);

                smtpClient.Send(mailMessage);

                MessageBox.Show("Poruka uspješno poslana pacijentu!");
                txtPorukaPregled.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Greška prilikom slanja emaila: {ex.ToString()}");
            }*/
        }

        private void btnSpremiPregled_Click(object sender, EventArgs e)
        {
            try
            {
                int idPacijent = Convert.ToInt32(id);
                string datum = txtDatumPregled.Text;
                string opis = txtOpisPregled.Text;

                using (SqlConnection DbConnection = new SqlConnection(@"Data Source=193.198.57.183;Initial Catalog=STUDENTI_TINF;Persist Security Info=True;User ID=tinf;Password=tinf123!;"))
                {
                    DbConnection.Open();

                    using (SqlCommand cmdInsert = new SqlCommand())
                    {
                        cmdInsert.Connection = DbConnection;
                        cmdInsert.CommandText = "INSERT INTO Jovanovic_PovijestBolesti (IdPacijent, Datum, Opis) VALUES (@IdPacijent, @Datum, @Opis); SELECT SCOPE_IDENTITY()";
                        cmdInsert.Parameters.AddWithValue("@IdPacijent", idPacijent);
                        cmdInsert.Parameters.AddWithValue("@Datum", datum);
                        cmdInsert.Parameters.AddWithValue("@Opis", opis);

                        // ExecuteScalar retrieves the newly inserted identity value
                        int newIdentity = Convert.ToInt32(cmdInsert.ExecuteScalar());

                        MessageBox.Show($"Pregled uspješno spremljen! Novi ID: {newIdentity}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Greška prilikom spremanja pregleda: {ex.Message}");
            }

            txtOpisPregled.Clear();
        }

        private void btnOBolnici_Click(object sender, EventArgs e)
        {
            panelListaPacijenata.Visible = true;
            panelDodajPacijenta.Visible = true;
            panelUrediPacijenta.Visible = true;

            panelListaCekanja.Visible = true;
            panelPregled.Visible = true;
            panelOBolnici.Visible = true;
        }
    }
}
