﻿namespace Bolnička_evidencija
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForm));
            this.txtKorisnickoIme = new System.Windows.Forms.TextBox();
            this.lblKorisnickoIme = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btnLogin = new System.Windows.Forms.Button();
            this.Zatvori = new System.Windows.Forms.Label();
            this.txtLozinka = new System.Windows.Forms.TextBox();
            this.lblLozinka = new System.Windows.Forms.Label();
            this.panelTopLogin = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBoxKriz = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBoxGif = new System.Windows.Forms.PictureBox();
            this.panelBottomLogin = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panelTopLogin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKriz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGif)).BeginInit();
            this.panelBottomLogin.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtKorisnickoIme
            // 
            this.txtKorisnickoIme.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtKorisnickoIme.Location = new System.Drawing.Point(208, 165);
            this.txtKorisnickoIme.Name = "txtKorisnickoIme";
            this.txtKorisnickoIme.Size = new System.Drawing.Size(500, 28);
            this.txtKorisnickoIme.TabIndex = 80;
            // 
            // lblKorisnickoIme
            // 
            this.lblKorisnickoIme.AutoSize = true;
            this.lblKorisnickoIme.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblKorisnickoIme.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblKorisnickoIme.Location = new System.Drawing.Point(93, 167);
            this.lblKorisnickoIme.Name = "lblKorisnickoIme";
            this.lblKorisnickoIme.Size = new System.Drawing.Size(111, 22);
            this.lblKorisnickoIme.TabIndex = 79;
            this.lblKorisnickoIme.Text = "Korisničko ime";
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.PowderBlue;
            this.label18.Font = new System.Drawing.Font("Palatino Linotype", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(97, 112);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(611, 26);
            this.label18.TabIndex = 77;
            this.label18.Text = "L - O - G - I - N";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnLogin
            // 
            this.btnLogin.AutoSize = true;
            this.btnLogin.BackColor = System.Drawing.Color.PowderBlue;
            this.btnLogin.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(353, 247);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(96, 32);
            this.btnLogin.TabIndex = 78;
            this.btnLogin.Text = "Login";
            this.btnLogin.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // Zatvori
            // 
            this.Zatvori.AutoSize = true;
            this.Zatvori.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Zatvori.Location = new System.Drawing.Point(761, 9);
            this.Zatvori.Name = "Zatvori";
            this.Zatvori.Size = new System.Drawing.Size(27, 25);
            this.Zatvori.TabIndex = 81;
            this.Zatvori.Text = "X";
            this.Zatvori.Click += new System.EventHandler(this.Zatvori_Click);
            // 
            // txtLozinka
            // 
            this.txtLozinka.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtLozinka.Location = new System.Drawing.Point(208, 199);
            this.txtLozinka.Name = "txtLozinka";
            this.txtLozinka.PasswordChar = '*';
            this.txtLozinka.Size = new System.Drawing.Size(500, 28);
            this.txtLozinka.TabIndex = 83;
            // 
            // lblLozinka
            // 
            this.lblLozinka.AutoSize = true;
            this.lblLozinka.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblLozinka.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblLozinka.Location = new System.Drawing.Point(93, 201);
            this.lblLozinka.Name = "lblLozinka";
            this.lblLozinka.Size = new System.Drawing.Size(66, 22);
            this.lblLozinka.TabIndex = 82;
            this.lblLozinka.Text = "Lozinka";
            // 
            // panelTopLogin
            // 
            this.panelTopLogin.BackColor = System.Drawing.Color.PowderBlue;
            this.panelTopLogin.Controls.Add(this.label2);
            this.panelTopLogin.Controls.Add(this.label1);
            this.panelTopLogin.Controls.Add(this.pictureBoxKriz);
            this.panelTopLogin.Controls.Add(this.Zatvori);
            this.panelTopLogin.Controls.Add(this.label3);
            this.panelTopLogin.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTopLogin.Location = new System.Drawing.Point(0, 0);
            this.panelTopLogin.Name = "panelTopLogin";
            this.panelTopLogin.Size = new System.Drawing.Size(800, 81);
            this.panelTopLogin.TabIndex = 84;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(161, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 28);
            this.label2.TabIndex = 3;
            this.label2.Text = "U Virovitici";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(68, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Bolnica Veleučilišta";
            // 
            // pictureBoxKriz
            // 
            this.pictureBoxKriz.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxKriz.Image")));
            this.pictureBoxKriz.Location = new System.Drawing.Point(12, 12);
            this.pictureBoxKriz.Name = "pictureBoxKriz";
            this.pictureBoxKriz.Size = new System.Drawing.Size(50, 50);
            this.pictureBoxKriz.TabIndex = 1;
            this.pictureBoxKriz.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(891, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "X";
            // 
            // pictureBoxGif
            // 
            this.pictureBoxGif.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxGif.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxGif.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGif.Image")));
            this.pictureBoxGif.Location = new System.Drawing.Point(12, 289);
            this.pictureBoxGif.Name = "pictureBoxGif";
            this.pictureBoxGif.Size = new System.Drawing.Size(120, 82);
            this.pictureBoxGif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxGif.TabIndex = 86;
            this.pictureBoxGif.TabStop = false;
            // 
            // panelBottomLogin
            // 
            this.panelBottomLogin.BackColor = System.Drawing.Color.PowderBlue;
            this.panelBottomLogin.Controls.Add(this.label5);
            this.panelBottomLogin.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottomLogin.Location = new System.Drawing.Point(0, 377);
            this.panelBottomLogin.Name = "panelBottomLogin";
            this.panelBottomLogin.Size = new System.Drawing.Size(800, 73);
            this.panelBottomLogin.TabIndex = 85;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.PowderBlue;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(97, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(611, 22);
            this.label5.TabIndex = 3;
            this.label5.Text = "Izradio LEO JOVANOVIĆ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBoxGif);
            this.Controls.Add(this.panelBottomLogin);
            this.Controls.Add(this.panelTopLogin);
            this.Controls.Add(this.txtLozinka);
            this.Controls.Add(this.lblLozinka);
            this.Controls.Add(this.txtKorisnickoIme);
            this.Controls.Add(this.lblKorisnickoIme);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.btnLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LoginForm";
            this.panelTopLogin.ResumeLayout(false);
            this.panelTopLogin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxKriz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGif)).EndInit();
            this.panelBottomLogin.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtKorisnickoIme;
        private System.Windows.Forms.Label lblKorisnickoIme;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label Zatvori;
        private System.Windows.Forms.TextBox txtLozinka;
        private System.Windows.Forms.Label lblLozinka;
        private System.Windows.Forms.Panel panelTopLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBoxKriz;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBoxGif;
        private System.Windows.Forms.Panel panelBottomLogin;
        private System.Windows.Forms.Label label5;
    }
}