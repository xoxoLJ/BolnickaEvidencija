﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Collections;

namespace Bolnička_evidencija
{
    public class Pacijent
    {
        public int id;
        public string ime;
        public string prezime;
        public string adresaStanovanja;
        public string emailAdresa;
        public int godina;
        public string spol;
        public string krvnaGrupa;
        public string brojMobitela;
        public bool cekanje;
    }
    public class PacijentPovijest
    {
        public int id;
        public int idPacijent;
        public string datum;
        public string opis;
    }

    public static class PacijentServis
    {
        private static List<Pacijent> listaPacijenata = new List<Pacijent>();
        private static List<Pacijent> listaCekanja = new List<Pacijent>();
        private static List<PacijentPovijest> listaPovijesti = new List<PacijentPovijest>();

        public static List<Pacijent> ListaPacijenata
        {
            get { return listaPacijenata; }
            set { listaPacijenata = value;}
        }

        public static List<Pacijent> ListaCekanja
        {
            get { return listaCekanja; }
            set { listaCekanja = value; }
        }

        public static List<PacijentPovijest> ListaPovijesti
        {
            get { return listaPovijesti; }
            set { listaPovijesti = value; }
        }
    }
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            LoginForm loginForm = new LoginForm();
            Application.Run(loginForm);
        }
    }
}
